self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4841c262e5330db95f26",
    "url": "/vue-crypto-dashboard/css/app.css"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "/vue-crypto-dashboard/fonts/fontawesome-webfont.eot"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "/vue-crypto-dashboard/fonts/fontawesome-webfont.ttf"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "/vue-crypto-dashboard/fonts/fontawesome-webfont.woff"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "/vue-crypto-dashboard/fonts/fontawesome-webfont.woff2"
  },
  {
    "revision": "acf3dcb7ff752b5296ca23ba2c7c2606",
    "url": "/vue-crypto-dashboard/img/fontawesome-webfont.svg"
  },
  {
    "revision": "c43ba705e5f5b519a612259bb0ed8957",
    "url": "/vue-crypto-dashboard/index.html"
  },
  {
    "revision": "4841c262e5330db95f26",
    "url": "/vue-crypto-dashboard/js/app.js"
  },
  {
    "revision": "962c02a209e573729415",
    "url": "/vue-crypto-dashboard/js/chunk-60bb78bb.js"
  },
  {
    "revision": "230ed56cd31988cf5393",
    "url": "/vue-crypto-dashboard/js/chunk-b76e42e8.js"
  },
  {
    "revision": "565871ff154acf3ade86",
    "url": "/vue-crypto-dashboard/js/chunk-vendors.js"
  },
  {
    "revision": "59b4fc26343074884653a2af117147f9",
    "url": "/vue-crypto-dashboard/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/vue-crypto-dashboard/robots.txt"
  }
]);